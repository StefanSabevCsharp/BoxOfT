﻿namespace GenericScale
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
           EqualityScale<string> str = new EqualityScale<string>("Pesho","Pesho");
            Console.WriteLine(str.AreEqual("Pesho", "Gosho"));
        }
    }
}